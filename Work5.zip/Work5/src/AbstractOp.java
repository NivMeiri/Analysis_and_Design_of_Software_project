public class AbstractOp {
    AirConditioner airco;
    public void ChangeTemp(){}
    public void Entry(String stri){
        System.out.println("OPERATION-"+stri);
    }
    public void Entry(){;}
}
