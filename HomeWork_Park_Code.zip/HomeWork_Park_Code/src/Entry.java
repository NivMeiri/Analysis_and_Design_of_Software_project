public class Entry {
    Device d;
    E_ticket e;
    Boolean used;

    public Entry(Device d){
        this.d=d;
    }
    public  void  setUsed(boolean b) {
        this.used = b;
    }
}
