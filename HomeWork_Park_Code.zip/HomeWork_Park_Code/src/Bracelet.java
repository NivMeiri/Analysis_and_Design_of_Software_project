public class Bracelet {
    String location;
    Child c;

    public Bracelet(){
        location="";
    }
}
